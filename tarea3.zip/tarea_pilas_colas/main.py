from pasajero import Pasajero
from mi_pila import MiPila
from mi_cola import MiCola

pila = MiPila(10)
cola = MiCola(10)


def leer_entero(mensaje):
    while True:
        try:
            return int(input(mensaje))
        except ValueError:
            print('  Debe ingresar un número entero.')


def leer_pasajero():
    numero = leer_entero('  N.º de pasajero: ')
    nombre = input('  Nombre: ').strip()
    cedula = input('  Cédula: ').strip()
    edad = leer_entero('  Edad: ')
    fecha = input('  Fecha de vuelo (AAAA-MM-DD): ').strip()
    destino = input('  Destino: ').strip()
    asiento = input('  Asiento: ').strip().upper()
    return Pasajero(numero, nombre, cedula, edad, fecha, destino, asiento)


def datos_prueba():
    return [
        Pasajero(1005, 'Diana', '0923456789', 22, '2026-11-15', 'Quito', '12A'),
        Pasajero(1002, 'Ana', '0912345678', 28, '2026-11-15', 'Lima', '03C'),
        Pasajero(1009, 'Luis', '0987654321', 35, '2026-11-20', 'Bogotá', '18F'),
        Pasajero(1004, 'Beto', '0934567890', 16, '2026-11-20', 'Quito', '07B'),
        Pasajero(1001, 'Elena', '0901234567', 41, '2026-11-22', 'Lima', '01A'),
    ]


def mostrar_opciones(titulo, entrar, salir, ver):
    print(f'\n========== {titulo} ==========')
    print(f' 1. {entrar:<12}  2. Listar          3. {salir}')
    print(f' 4. {ver:<12}  5. Buscar          6. Modificar')
    print(' 7. Eliminar por número         8. Copiar')
    print(' 9. Longitud / ¿vacía?')
    print(' C. Cargar datos de prueba      0. Volver')


def menu_pila():
    while True:
        mostrar_opciones('MENÚ 1 · PILA (LIFO)', 'Apilar', 'Desapilar', 'Ver tope')
        op = input('Opción: ').strip().upper()
        if op == '1':
            pasajero = leer_pasajero()
            if pila.apilar(pasajero):
                print('  Pasajero apilado correctamente')
        elif op == '2':
            pila.listar()
        elif op == '3':
            pasajero = pila.desapilar()
            if pasajero is not None:
                print(f'  Salió: {pasajero}')
        elif op == '4':
            pasajero = pila.ver_tope()
            print(f'  Tope: {pasajero}' if pasajero is not None else '  La pila está vacía')
        elif op == '5':
            numero = leer_entero('  Número de pasajero a buscar: ')
            pos = pila.buscar(numero)
            print(f'  Encontrado en [{pos}]: {pila.datos[pos]}' if pos != -1 else '  No existe')
        elif op == '6':
            numero = leer_entero('  Número de pasajero a modificar: ')
            destino = input('  Nuevo destino: ').strip()
            asiento = input('  Nuevo asiento: ').strip().upper()
            print('  Modificado correctamente' if pila.modificar(numero, destino, asiento) else '  No existe')
        elif op == '7':
            numero = leer_entero('  Número de pasajero a eliminar: ')
            print('  Pasajero eliminado' if pila.eliminar_por_numero(numero) else '  No existe')
        elif op == '8':
            print('  --- COPIA DE LA PILA ---')
            pila.copiar().listar()
        elif op == '9':
            print(f'  Longitud: {pila.longitud()}')
            print('  Está vacía' if pila.esta_vacia() else '  No está vacía')
        elif op == 'C':
            agregados = 0
            for pasajero in datos_prueba():
                if pila.apilar(pasajero):
                    agregados += 1
            print(f'  Pasajeros nuevos cargados: {agregados}')
        elif op == '0':
            break
        else:
            print('  Opción no válida')


def menu_cola():
    while True:
        mostrar_opciones('MENÚ 2 · COLA (FIFO)', 'Encolar', 'Desencolar', 'Ver frente')
        op = input('Opción: ').strip().upper()
        if op == '1':
            pasajero = leer_pasajero()
            if cola.encolar(pasajero):
                print('  Pasajero encolado correctamente')
        elif op == '2':
            cola.listar()
        elif op == '3':
            pasajero = cola.desencolar()
            if pasajero is not None:
                print(f'  Salió: {pasajero}')
        elif op == '4':
            pasajero = cola.ver_frente()
            print(f'  Frente: {pasajero}' if pasajero is not None else '  La cola está vacía')
        elif op == '5':
            numero = leer_entero('  Número de pasajero a buscar: ')
            pos = cola.buscar(numero)
            print(f'  Encontrado en [{pos}]: {cola.datos[pos]}' if pos != -1 else '  No existe')
        elif op == '6':
            numero = leer_entero('  Número de pasajero a modificar: ')
            destino = input('  Nuevo destino: ').strip()
            asiento = input('  Nuevo asiento: ').strip().upper()
            print('  Modificado correctamente' if cola.modificar(numero, destino, asiento) else '  No existe')
        elif op == '7':
            numero = leer_entero('  Número de pasajero a eliminar: ')
            print('  Pasajero eliminado' if cola.eliminar_por_numero(numero) else '  No existe')
        elif op == '8':
            print('  --- COPIA DE LA COLA ---')
            cola.copiar().listar()
        elif op == '9':
            print(f'  Longitud: {cola.longitud()}')
            print('  Está vacía' if cola.esta_vacia() else '  No está vacía')
        elif op == 'C':
            agregados = 0
            for pasajero in datos_prueba():
                if cola.encolar(pasajero):
                    agregados += 1
            print(f'  Pasajeros nuevos cargados: {agregados}')
        elif op == '0':
            break
        else:
            print('  Opción no válida')


def main():
    while True:
        print('\n===== TAREA PILAS Y COLAS · PASAJEROS =====')
        print('1. Menú 1 · Pila')
        print('2. Menú 2 · Cola')
        print('3. Salir')
        op = input('Opción: ').strip()
        if op == '1':
            menu_pila()
        elif op == '2':
            menu_cola()
        elif op == '3':
            print('¡Hasta pronto!')
            break
        else:
            print('Opción no válida')


if __name__ == '__main__':
    main()
