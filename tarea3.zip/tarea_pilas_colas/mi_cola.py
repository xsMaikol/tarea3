class MiCola:
    """Cola FIFO de pasajeros con arreglo de capacidad fija."""

    def __init__(self, capacidad=10):
        self.datos = [None] * capacidad
        self.capacidad = capacidad
        self.cantidad = 0

    def encolar(self, pasajero):
        if self.cantidad == self.capacidad:
            print('  La cola está llena')
            return False
        if self.buscar(pasajero.numero) != -1:
            print('  Ya existe un pasajero con ese número')
            return False
        self.datos[self.cantidad] = pasajero
        self.cantidad += 1
        return True

    def listar(self):
        if self.esta_vacia():
            print('  (cola vacía)')
            return
        for i in range(self.cantidad):
            marca = '  ← FRENTE' if i == 0 else ('  ← FINAL' if i == self.cantidad - 1 else '')
            print(f'  [{i}] {self.datos[i]}{marca}')

    def desencolar(self):
        if self.esta_vacia():
            print('  La cola está vacía')
            return None
        pasajero = self.datos[0]
        for i in range(self.cantidad - 1):
            self.datos[i] = self.datos[i + 1]
        self.datos[self.cantidad - 1] = None
        self.cantidad -= 1
        return pasajero

    def ver_frente(self):
        if self.esta_vacia():
            return None
        return self.datos[0]

    def buscar(self, numero):
        for i in range(self.cantidad):
            if self.datos[i].numero == numero:
                return i
        return -1

    def modificar(self, numero, nuevo_destino, nuevo_asiento):
        pos = self.buscar(numero)
        if pos == -1:
            return False
        self.datos[pos].destino = nuevo_destino
        self.datos[pos].asiento = nuevo_asiento
        return True

    def eliminar_por_numero(self, numero):
        inicial = self.cantidad
        encontrado = False
        for i in range(inicial):
            pasajero = self.desencolar()
            if pasajero.numero == numero:
                encontrado = True
            else:
                self.encolar(pasajero)
        return encontrado

    def copiar(self):
        copia = MiCola(self.capacidad)
        for i in range(self.cantidad):
            copia.encolar(self.datos[i])
        return copia

    def longitud(self):
        return self.cantidad

    def esta_vacia(self):
        return self.cantidad == 0
